# app/forms.py

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField, FileField
from wtforms.validators import DataRequired, Email, EqualTo, Length

class RegistrationForm(FlaskForm):
    username = StringField(
        'Username', 
        validators=[DataRequired(message="Username is required"), Length(min=2, max=20)]
    )
    email = StringField(
        'Email', 
        validators=[DataRequired(message="Email is required"), Email(message="Enter a valid email")]
    )
    password = PasswordField(
        'Password', 
        validators=[DataRequired(message="Password is required")]
    )
    confirm_password = PasswordField(
        'Confirm Password', 
        validators=[DataRequired(message="Confirm your password"), EqualTo('password', message="Passwords must match")]
    )
    submit = SubmitField('Sign Up')


class LoginForm(FlaskForm):
    email = StringField(
        'Email', 
        validators=[DataRequired(message="Email is required"), Email(message="Enter a valid email")]
    )
    password = PasswordField(
        'Password', 
        validators=[DataRequired(message="Password is required")]
    )
    submit = SubmitField('Login')


class CrimeReportForm(FlaskForm):
    title = StringField(
        'Title', 
        validators=[DataRequired(message="Title is required")]
    )
    description = TextAreaField(
        'Description', 
        validators=[DataRequired(message="Description is required")]
    )
    evidence = FileField(
        'Upload Evidence'  # <-- Added this line
    )
    submit = SubmitField('Submit Report')
